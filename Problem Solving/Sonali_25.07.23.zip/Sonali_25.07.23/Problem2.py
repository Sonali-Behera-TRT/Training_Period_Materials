class Array:
  def __init__(self, arr): self.arr = arr

  def map(self, callBackFn):
    ans = []
    for i in self.arr:
      ans.append(callBackFn(i))
    return ans

  def reduce(self, callBackFn, initialValue):
    ans = initialValue
    for i in self.arr:
      ans = callBackFn(ans, i)
    return ans

  def filter(self, callBackFn):
    ans = []
    for i in self.arr:
      if(callBackFn(i)):
        ans.append(i)
    return ans

array = Array([1, 2, 3, 4, 5])
print('Original array: ', array.arr)
print('With polyfill map(): ', array.map(lambda x: x ** 2))
print('With polyfill filter(): ', array.filter(lambda i: i %2 == 0))
print('With polyfill reduce(): ', array.reduce((lambda i, j:  i + j), 5))