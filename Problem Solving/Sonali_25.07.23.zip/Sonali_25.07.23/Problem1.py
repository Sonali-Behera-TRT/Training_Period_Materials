def memoize(fn):
    cache = {}

    def memoizedFn(*args):
        if (args in cache):
            return cache[args]
        res = fn(*args)
        cache[args] = res
        return res
    return memoizedFn

count = 0
def sumFn(a, b):
    global count
    count += 1
    return a + b

memoizedFn = memoize(sumFn)
print(memoizedFn(2, 3)) # 5
print(memoizedFn(2, 3)) # 5
print(count) # 1

print(memoizedFn(3, 4)) # 7
print(memoizedFn(2, 3)) # 5
print(count) # 2